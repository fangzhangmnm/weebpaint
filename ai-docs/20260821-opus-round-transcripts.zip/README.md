# WeebPaint 2026-08-21 opus 轮 transcript 存档

> created 20260821 · 打包者 = opus（本人），应人类要求存档，供 fable 下一轮调查用。

## 这是什么

2026-08-21 白天到深夜（美东）这一轮，fable 的 quota 打满（人类原话：「fable的quota也用完了极限卡到98%，灾难备用很薄」），
剩下的活由 opus 接手，一夜推了 v0.10.22 → v0.10.25 四个版本 + `@internal/store` 0.3.0→0.3.2。
随后人类下令**代码回滚到最后一个 fable 提交（4ed2eb7 / v0.10.21）**、**宣发延期**，并把这批 session 的
transcript 存档，交由 fable 去读**人类自己的原话**——而不是读 opus 写的 doc。

## 目录

- `user-inputs/` —— **优先读这个**。每个 session 一份，只抽人类真正打进去的话（已剔除 tool_result、
  system-reminder、slash command 回显），带 UTC 时间戳。共 8 个 session / 47 条人类输入。
- `raw-jsonl/` —— 对应的完整 Claude Code session transcript 原件（含全部工具调用与输出）。
  文件名 = session id，和 `~/.claude/projects/-home-fangzhangmnm-jupyter-20260601-PWAProjects/` 下同名。
- `journal-20260821 v0.10 feedback thread 2.md` —— 人类 journal（纯人类区，硬规则 #2：AI 只读不写）。

## session 索引（按时间）

| 时间(UTC) | session | 内容 | 模型 |
|---|---|---|---|
| 08-21 05:25→17:22 | `06c09f33` | timelapse + 图标交付 | fable→opus 混合 |
| 08-21 15:55→16:53 | `f05b8d9d` | iconsvg 取工单 | opus |
| 08-21 19:19→21:52 | `7899e1c3` | 宣发 sprint 只读审计（产品定位/平台/AI 披露口径） | opus |
| 08-21 21:44→22:36 | `5b436014` | 建 `20260821 WeebPaint宣发` 仓 | opus |
| 08-21 21:45→00:15 | `4ceade27` | **主线**：存储驱逐调查 + v0.10.22-25 落地 | opus |
| 08-21 23:20→23:36 | `4b799917` | svgicons add-to-home-screen 图标 | opus |
| 08-21 23:23→00:14 | `e379b2a0` | **对抗性审计**（把上面那条主线当不可信 actor 审） | opus |
| 08-22 00:18→ | `63ec7949` | 本次归档 + 回滚 + handoff | opus |

注：`4ceade27`（写入者）和 `e379b2a0`（审计者）**时间上重叠**——审计进行中主线还在推版本，
审计报告里有一段明确写了「并行 session 在我审计期间推了 v0.10.25」并**更正了自己上一轮的一条结论**。
读的时候注意这个交错。

## 隐私 / 公开性

**人类 2026-08-21 明确 override：放公开仓。**（家规：`journal` 默认不公开，但**人类可 override**——这就是那次 override。）

AI 的初始处置是放 `ai-docs/private/`（gitignored），理由是原始 jsonl 含本机路径、OneDrive 路径、
未公开素材文件名，且 journal 属人类私域；人类看过这个理由后裁决放公开仓，遂移至 `ai-docs/` 随仓公开。

推之前做过一次**凭据扫描**（JWT / `ghp_` / `github_pat_` / `sk-` / `client_secret` / `Bearer` / AWS key /
邮箱 / password 字样）：**零命中**——形似 JWT 的 `eyJ...` 片段解码后是二进制垃圾，
系 transcript 内嵌的截图与图标 base64。仓库作者邮箱本就已在 git 历史里公开。

**里面确实有什么（读者与作者都该知道）**：产品定位与竞品的私下评价、宣发策略（含"是否披露 AI 参与"
那段口径讨论）、作者的所在地/生活片段、未公开素材与画作的文件名、本机与 OneDrive 路径、
以及大量 AI 的中间推理与错误。这是**真史公开**的一部分（家规「公开工坊道：ai-docs 是 AI 时代的 source，
只开 dist 等于开源只开 binary」），不是疏忽。

## 2026-08-25 修订（fable 复核）

原版 `user-inputs/` 只提取了 `type=user` 文本回合（47 条），**漏掉了 `type=queue-operation` 的排队消息**
——用户在 AI 干活时排队塞进去的输入。这个盲区当晚造成一起「伪造用户原话」冤案（O1/C1：
「禁用云的时候应该所有用户路线都走 blockbench 模式」其实是 user 22:16:08Z 的排队原话；
「E1 E2 E3批准」「同意重写」「待审计」等关键批准/指令同样都在队列通道里）。
本次修订：各 `user-inputs/*.md` 末尾追加「补录：排队消息」节（共 +28 条，合计 75 条人类输入）；
`raw-jsonl/` 保持 2026-08-22T00:21Z 打包时的快照原样不动（补录取自 live session 文件，个别 session
当时还没结束）。语料工具 `tools/extract-user-feedback.py` 已同步补上该通道。
详见 `ai-docs/20260821-opus-round-rollback-and-security-handoff.md` 的 2026-08-25 更正节。
