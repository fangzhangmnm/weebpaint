// @internal/gallery 门牌——出生 2026-09-09（Claude Fable 5.1）。提案 = ai-docs/20260909-proposal-api.md。
// 本版 = core/ 纯核（无 DOM）：model / guards / library / boot / backup + 三个注入 seam（text / device-kv / naming）。UI 层随后。
export const GALLERY_PACKAGE_BIRTH = "2026-09-09" as const;
export * from "./core/text.ts";
export * from "./core/device-kv.ts";
export * from "./core/naming.ts";
export * from "./core/model/gallery-model.ts";
export * from "./core/model/gallery-path.ts";
export * from "./core/model/natural-order.ts";
export * from "./core/model/timeline-order.ts";   // 0.8.12：时间线的顺序（作品和文件夹同一套明文规则）
export * from "./core/model/versions.ts";   // 0.9.0：「存下来的一版」的名字规则（<原主干>.backup-<日期>[-n]）
export * from "./core/model/fold-groups.ts";   // 0.9.0：收起（细条 / 原作卡片上的 +N）= 纯显示的归组
export * from "./core/model/gallery-view-model.ts";
export type { AsideKind, AsideScope, AsideItem, AsideEmptyResult } from "./core/model/aside.ts";   // 0.5.0：搁置区（回收站 / 备份箱）只出类型；差异表 ASIDE 不出门
export * from "./core/model/cloud-image-model.ts";
export * from "./core/guards/frame-gate.ts";
export * from "./core/guards/first-frame-watchdog.ts";
export * as diagLog from "./core/guards/diag-log.ts";
export * from "./core/library/gallery-registry.ts";
export * from "./core/library/gallery-attachment.ts";
export * from "./core/library/gallery-capability.ts";
export * from "./core/library/active-gallery.ts";
export * from "./core/boot/resume-slate.ts";
export * from "./core/boot/boot-restore.ts";
export * from "./core/backup/library-backup.ts";
export * from "./core/backup/change-password.ts";
export * from "./core/data-face.ts";
export * from "./core/verbs.ts";
export * from "./core/thumbs/thumb-store.ts";
export * from "./core/thumbs/thumb-cache.ts";
export * from "./core/thumbs/peek-thumb.ts";
export * from "./core/thumbs/png-text.ts";
export * from "./core/thumbs/make-thumb.ts";
export * from "./core/facts/facts-cache.ts";   // 0.8.0：卡片的「事实」缓存
export * from "./ui/store-ui.ts";
export * from "./ui/gallery-screen.ts";
export * from "./ui/shell-flows.ts";
export * from "./ui/cloud-auth-chip.ts";
export * from "./create-gallery.ts";
