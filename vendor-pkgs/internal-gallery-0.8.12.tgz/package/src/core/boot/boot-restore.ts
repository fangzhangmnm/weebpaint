// boot-restore —— 「冷启动要不要自动打开上次那张画」的**纯编排**（v438）。
//
// 为什么单独一个文件：boot.ts 静态 import 了 session-state → app-store（模块求值就建 store）→ vue …
//   所以 boot.ts **在 node 测试里 import 不动**，这段逻辑一直零覆盖。而它守着两条真纪律：
//     ① 幽灵路径（feedback-phantom-current-path）：加载失败时内存名必须降回 safe default，
//        否则后续 save/rename 会把「加载失败的那个 path」当 oldName 去动（AtlasMaker 0.7.2 吃过一个加密文件）。
//     ② 失败**不清**持久的 currentFile：失败常是瞬态的（取消密码框 / 离线只有云端副本 / 文件锁定），
//        清了用户下次冷启动就再也不会自动开这张画。v406-v408 这里无条件 setName(null) 把两者一起清了，v409 修。
//   两条都是「失败路径上的事」，恰恰是最不容易被真机测到、也最容易被下一次重构悄悄改掉的部分。
//
// 端口全注入 → 这个模块对 app 一无所知，测试可以直接驱动它。
import type { ResumeOpened } from "./resume-slate.ts";

export interface RestorePorts {
  /** 回执条的 opened（P5 2026-08-27：typed union 取代 null/""/名 三态哨兵——resume-slate 器官）。
   *  null=从未绑定（首次）→ 新画布；{kind:"gallery"}=上次停在图库（有意）→ 图库；
   *  {kind:"doc",path} → 自动恢复它（P1.5 拍板语义原样）。 */
  getResume(): ResumeOpened;
  /** 真正去开（store.file.open + adopt）。返回是否装入了字节。 */
  restore(name: string): Promise<boolean>;
  /** 只改内存里的活动名，**不动持久的 currentFile**（= session.setName(x, {persist:false})）。 */
  setNameMemoryOnly(name: string | null): void;
  /** 「上次就停在图库」（wanted 为空 = 用户离开时的**有意**状态）的落点。
   *  ⚠ canvas-first（P1 2026-08-26，verdicts §2.4「boot 永不 404 跳 gallery」）：只有这条有意路
   *  还落图库；失败/断路/锁 三条路一律落画布——图库不是失败的垃圾桶。 */
  openGallery(): Promise<void>;
  updateSaveStatus(): void;
  onOpened(name: string): void;
  onNotFound(name: string): void;
  // ── 崩溃环断路器（v0.10.9，纪律③）：跨崩溃记「正在开谁」的持久标记（P5 起住 resume-slate，
  //    与 opened 同记录）──
  /** 上次 boot 留下的 attempt 标记（优雅收场会清 null；非 null = 上次死在开它的半路）。 */
  getRestoreAttempt(): string | null;
  /** ⚠ 契约：本写入必须**同步落盘**（slate 器官 = localStorage 单键写天然满足）——OOM 崩溃可比任何
   *  防抖快。v0.10.9 的 flushMarker 端口因此退役（P5 2026-08-27）。 */
  setRestoreAttempt(name: string | null): void;
  onCrashLoopSkipped(name: string): void;
  // ── 双实例互认（Web Locks，2026-08-21 双实例案）：wanted 是否被**别的窗口**持有 ──
  /** 无 Web Locks 支持时恒 false（整套降级为现状，行为不变）。 */
  isDocLockedElsewhere(name: string): Promise<boolean>;
  onLockedElsewhere(name: string): void;
  // ── 云端功能开关（2026-08-21，cloud-capability 接缝）：关 = boot 不自动恢复 store 画 ──
  /** 关闭态恒 false（含容器未配置 auth）。 */
  hasGallery(): boolean;
  /** 云关落点（P1.5 起**只剩云关这一条路**用它）：plain 空白画布（无 store 家可安，无 session 绑定；
   *  P2 transient 接手后升级）。⚠ 纯 UI 落点，零数据变更：currentFile/标记一个都不碰。 */
  openBlankCanvas(): Promise<void>;
  /** 云关落点的提示文案（为什么没自动开上次的画）——与 openBlankCanvas 分离：落点共用、文案各表。 */
  onNoGallery(): void;
  /** 云开态的画布落点（P1.5）= **可画的新画布**（lazyblank：日期默认名、首笔自动安家进图库——
   *  瑞士奶酪：云开态不许存在「能画但存不了」的画布）。首次 + 失败/断路/锁 四条路共用；
   *  与 openBlankCanvas（云关 plain blank，无 store 家可安，P2 transient 接手）分开。
   *  内部自管身份（memory-only 日期名），故这些路径先 setNameMemoryOnly(null) 再调它不冲突。 */
  openFreshCanvas(): Promise<void>;
}

export type RestoreOutcome = "restored" | "fresh-first-boot" | "gallery-deliberate" | "blank-failed" | "blank-crash-loop" | "blank-locked-elsewhere" | "blank-no-gallery";

export async function restoreLastSession(p: RestorePorts): Promise<RestoreOutcome> {
  // ★ 云端功能关（2026-08-21）：不自动恢复、也不落图库（gating ①把图库藏了）→ 空白画布。
  //   排在最前：断路器/双实例检查都是「要去开 wanted」的前置，关闭态压根不开，标记与
  //   持久 currentFile 全都**原样不动**（纪律②的语义不被本门毒化；关→开自愈）。
  if (!p.hasGallery()) {
    p.setNameMemoryOnly(null);          // 幽灵路径纪律①同款：内存名必须是 safe default
    p.updateSaveStatus();
    await p.openBlankCanvas();
    p.onNoGallery();
    return "blank-no-gallery";
  }
  const resume = p.getResume();
  if (resume == null) {
    // ★ 首次（从未绑定）→ 新画布（P1.5 拍板）。openFreshCanvas 自管 lazyblank 身份。
    p.setNameMemoryOnly(null);          // 幽灵路径纪律①：先降 safe default，身份由落点重立
    p.updateSaveStatus();
    await p.openFreshCanvas();
    return "fresh-first-boot";
  }
  if (resume.kind === "gallery") {
    // ★ 上次离开时就停在图库（有意状态）→ 图库（这不是 404 fallback，canvas-first 不适用）。
    p.setNameMemoryOnly(null);
    p.updateSaveStatus();
    await p.openGallery();
    return "gallery-deliberate";
  }
  const wanted = resume.path;
  // ★ 纪律④（双实例互认，2026-08-21）：wanted 正被**另一个活窗口**持有 ⇒ ① 不自动开
  //   （双 tab 同画编辑 = 本地字节互覆，入口拦住）；② 这也**不是崩溃**——上一实例还活着，
  //   restoreAttempt 标记只是还没到清点（慢加载/正编辑中）。所以本检查必须排在断路器判定
  //   **之前**：否则「A 冷启动写了标记、慢加载中用户开 B」会让 B 读到 A 的在途标记误判崩溃环。
  //   标记**原样不动**（不写不清）——断路器语义不被消耗：A 若真死在半路，锁被浏览器自动释放
  //   （Web Locks 语义），下次 boot 无锁 + 标记在场 → 照常断路。
  if (await p.isDocLockedElsewhere(wanted)) {
    p.setNameMemoryOnly(null);
    p.updateSaveStatus();
    await p.openFreshCanvas();          // canvas-first：不跳 gallery，落可画新画布，status 说清「在另一窗口」
    p.onLockedElsewhere(wanted);
    return "blank-locked-elsewhere";
  }
  // ★ 纪律③（崩溃环断路，v0.10.9）：标记 == 想开的画 ⇒ 上次 boot 死在开它的半路（小内存设备
  //   开超大文件 OOM 被杀等——tab 直接死，永远走不到下面的「优雅失败」分支）。若无此闸，
  //   currentFile 有意不清（纪律②）+ 无条件自动开 = 每次冷启动重开必死的画，用户连图库都进不去。
  //   跳过自动开、落可画新画布（canvas-first）；标记**保留**（之后每次 boot 都跳），直到任意画成功打开
  //   （setCurrentSessionName 清标记）或下次自动开换了目标（下面 setRestoreAttempt 覆写）。
  if (p.getRestoreAttempt() === wanted) {
    p.setNameMemoryOnly(null);
    p.updateSaveStatus();
    await p.openFreshCanvas();          // canvas-first：断路落可画新画布，status 说清为什么没自动开
    p.onCrashLoopSkipped(wanted);
    return "blank-crash-loop";
  }
  p.setRestoreAttempt(wanted);        // 同步落盘（端口契约）——写完即安全，restore 随后
  if (await p.restore(wanted)) {
    p.setRestoreAttempt(null);          // 优雅收场①：成功（setCurrentSessionName 也会清——幂等）
    p.onOpened(wanted);
    return "restored";
  }
  // ★ 失败：内存名降回 null（纪律①），持久 currentFile **一个指头都不碰**（纪律②）。
  //   标记也清——优雅失败=瞬态（取消密码框/离线只有云端副本/文件锁定），下次冷启动照常 retry，
  //   纪律②的语义不被断路器毒化。
  p.setRestoreAttempt(null);
  p.setNameMemoryOnly(null);
  p.updateSaveStatus();
  await p.openFreshCanvas();            // canvas-first（verdicts §2.4）：404 不跳 gallery，落可画新画布，status 如实报
  p.onNotFound(wanted);
  return "blank-failed";
}
